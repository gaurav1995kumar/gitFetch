package com.gaurav.gitFetchDetails.repository;

import org.springframework.data.repository.CrudRepository;

import com.gaurav.gitFetchDetails.model.BuildDetails;

public interface GitFetchMongoRepository extends CrudRepository<BuildDetails, String>{

}
