package com.gaurav.gitFetchDetails.model;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "buildDetails")
public class BuildDetails {
	
	private String orgName;
	
	private JSONObject repo;
	
	private JSONArray contributors;
	
	private JSONArray messages;
	
	private String Category = "Build";
	
	private String toolName = "Git";

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public JSONObject getRepo() {
		return repo;
	}

	public void setRepo(JSONObject repo) {
		this.repo = repo;
	}

	public JSONArray getContributors() {
		return contributors;
	}

	public void setContributors(JSONArray contributors) {
		this.contributors = contributors;
	}

	public JSONArray getMessages() {
		return messages;
	}

	public void setMessages(JSONArray messages) {
		this.messages = messages;
	}
	
	

}
