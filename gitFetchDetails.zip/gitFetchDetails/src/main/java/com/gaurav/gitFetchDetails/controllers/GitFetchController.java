package com.gaurav.gitFetchDetails.controllers;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gaurav.gitFetchDetails.model.BuildDetails;
import com.gaurav.gitFetchDetails.repository.GitFetchMongoRepository;

@Controller
public class GitFetchController {

	@Autowired
	GitFetchMongoRepository gitFetchMongoRepository;
	
	@RequestMapping("/home")
    public String home(Model model) {
        return "home";
    }
	
	@RequestMapping(value = "/fetch", method = RequestMethod.POST)
	public String fetch(@ModelAttribute BuildDetails buildDetails) {
		
		String orgName = buildDetails.getOrgName();
		JSONArray repos = null;
		JSONArray contributors = null;
		JSONArray messages = null;
		
		HttpConn Conn = new HttpConn();
		try {
		repos = Conn.getJsonArray("https://api.github.com/orgs/" + orgName + "/repos");
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
		
		
		for (int i = 0; i < repos.size(); i++) {

			JSONObject repoObj = (JSONObject) repos.get(i);

			String repoName = (String) repoObj.get("name");

			try {
			contributors = Conn.getJsonArray(
					"https://api.github.com/repos/" + orgName + "/" + repoName + "/contributors");

			messages = Conn
					.getJsonArray("https://api.github.com/repos/" + orgName + "/" + repoName + "/commits");
			}
			catch (Exception e) {
				// TODO: handle exception
			}
			
			buildDetails.setRepo(repoObj);
			buildDetails.setContributors(contributors);
			buildDetails.setMessages(messages);
			
			gitFetchMongoRepository.save(buildDetails);
			
		}
		
		
		return "redirect:home";
	}
	
}
