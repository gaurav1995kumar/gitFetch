package com.gaurav.gitFetchDetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GitFetchDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GitFetchDetailsApplication.class, args);
	}
}
